﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lambda_Tienda
{
    delegate string Descuento(double compra);
    class Delegado
    {
        public string Calculo(double compra) {
            double desc;
            if (compra >= 10000 && compra <= 20000) { desc = compra * 0.10;}
            else if (compra >= 20001 && compra <= 50000) { desc = compra * 0.30;}
            else if (compra > 50000) { desc = compra * 0.50; }
            else { desc = 0; }
            return"La compra ha sido por: $"+compra+"\nDescuento de: $"+desc+"\nTotal a pagar es: $"+(compra-desc);
        }
    }
}
