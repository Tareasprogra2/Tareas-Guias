﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lambda_Tienda
{
    class Program
    {
        static void Main(string[] args)
        {
            Delegado dlg = new Lambda_Tienda.Delegado();

            Console.WriteLine("-----Bienvenido-----");
            Console.Write("Ingrese el valor de la compra: ");
            double compra =Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("--------------------------------------------------");
            Descuento delegadoCalc = dlg.Calculo;
            Console.WriteLine(delegadoCalc(compra));

            Console.ReadKey();
        }
    }
}
