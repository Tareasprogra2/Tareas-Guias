﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial4_2515282019.Models
{
    public class DatosCompra
    {
        public int cantidad { get; set; }
        public double precio { get; set; }
        public double descuento { get; set; }
        public double pago { get; set; }
    }
}