﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Parcial4_2515282019.Models
{
    public class DatosEstudiante
    {
        public string nomEstudiante { get; set; }
        public string codEstudiante { get; set; }
        public string Materia { get; set; }
        public double nota1 { get; set; }
        public double nota2 { get; set; }
        public double nota3 { get; set; }
        public string resultado { get; set; }
    }
}