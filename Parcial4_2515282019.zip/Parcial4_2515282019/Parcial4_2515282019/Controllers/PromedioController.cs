﻿using Parcial4_2515282019.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Parcial4_2515282019.Controllers
{
    public class PromedioController : Controller
    {
        // GET: Promedio
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Promedio()
        {
            DatosEstudiante objModel = new DatosEstudiante();
            objModel.nomEstudiante = Request.Form["nombreEst"];
            objModel.codEstudiante = Request.Form["codEst"];
            objModel.Materia = Request.Form["materia"];
            objModel.nota1 = double.Parse(Request.Form["nota1"].ToString());
            objModel.nota2 = double.Parse(Request.Form["nota2"].ToString());
            objModel.nota3 = double.Parse(Request.Form["nota3"].ToString());

            double promedio = (objModel.nota1 + objModel.nota2 + objModel.nota3)/3;

            if (promedio >= 4) {objModel.resultado = "Felicidades, usted ha APROBADO"; }
            else { objModel.resultado= "Lamentablemente usted ha reprobado"; }
            return View("Promedio", objModel);
        }
    }
}