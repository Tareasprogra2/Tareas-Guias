﻿using Parcial4_2515282019.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Parcial4_2515282019.Controllers
{
    public class CompraController : Controller
    {
        // GET: Compra
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Compra()
        {
            DatosCompra objModel = new DatosCompra();
            objModel.cantidad = int.Parse(Request.Form["cantidad"]);
            objModel.precio = double.Parse(Request.Form["precio"]);
            double compra;
            compra = objModel.cantidad * objModel.precio;
            if (compra >= 100000)
            {
                objModel.descuento = compra * 0.20;
            }
            else { objModel.descuento = 0; }
            objModel.pago = compra - objModel.descuento;
            return View("Compra",objModel);
        }
    }
}